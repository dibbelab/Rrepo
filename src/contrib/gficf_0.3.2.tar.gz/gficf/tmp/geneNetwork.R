geneNetwork = function(data,k=250,community.algo="louvian 2",nt=6,verbose=T)
{
  library(gficf)
  k=1000;community.algo="louvian 2";nt=6;verbose=T
  resolution=.95;n.start=25;n.iter=50;seed=0
  data = loadGFICF("~/BRCA.gficf")
  idx = t(apply(data$gficf, 1, function(x,y=k) order(x,decreasing = T)[1:y]))
  RcppParallel::setThreadOptions(numThreads = nt)

  relations <- gficf:::rcpp_parallel_jaccard_coef_2(idx,verbose)
  rownames(relations) = colnames(relations) = rownames(idx)
  # g <- igraph::graph.adjacency(adjmatrix = relations, weighted = T,diag = F,mode = "undirected")
  # rm(relations,idx);gc()
  
  if (community.algo=="louvian")
  {
    tsmessage("Performing louvain...",verbose = verbose)
    community <- igraph::cluster_louvain(g)
  }
  
  if (community.algo=="louvian 2")
  {
    tsmessage("Performing louvain with modularity optimization...",verbose = verbose)
    tmp = relations
    tmp[tmp<=quantile(tmp,.75)] = 0
    tmp = Matrix::Matrix(data = tmp)
    g <- igraph::graph.adjacency(adjmatrix = tmp, weighted = T,diag = F,mode = "undirected")
    tmp2 = igraph::as_adjacency_matrix(g,attr = "weight",sparse = T)
    community <- gficf:::RunModularityClustering(tmp2,1,resolution,1,n.start,n.iter,seed,verbose)
  }
  
  if (community.algo=="louvian 3")
  {
    tsmessage("Performing louvain with modularity optimization...",verbose = verbose)
    community <- gficf:::RunModularityClustering(relations,1,resolution,2,n.start,n.iter,seed,verbose)
  }
  
  if (community.algo=="walktrap")
  {
    tsmessage("Performing walktrap...",verbose = verbose)
    community <- igraph::walktrap.community(g)
  } 
  if (community.algo=="fastgreedy") {
    tsmessage("Performing fastgreedy...",verbose = verbose)
    community <- igraph::fastgreedy.community(g)
  }
  
  if (community.algo=="leiden")
  {
    if (!(reticulate::py_module_available("leidenalg") && reticulate::py_module_available("igraph")))
      stop("Cannot find Leiden algorithm, please install through pip (e.g. sudo -H pip install leidenalg igraph).")
    
    tsmessage("Performing leiden...",verbose = verbose)
    community <- leiden::leiden(object = g,resolution_parameter=resolution)
  }
  
  
  if(community.algo %in% c("louvian 2","louvian 3","leiden")) {
    if(community.algo %in% c("louvian 2","louvian 3")) {community = community + 1}
    data$embedded$cluster = as.character(community)
  } else {
    data$embedded$cluster <- as.character(igraph::membership(community))
  }
  
  if (store.graph) {data$community=community;data$cell.graph=g} else {data$community=community}
  
}
