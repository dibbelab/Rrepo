library(testthat)
library(gficf)

# test_check("gficf")
