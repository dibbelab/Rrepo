library(ggplot2)
library(gficf)
library(Matrix)

M.raw = readRDS(file = "~/Dropbox/pseudoT.example.rds")
celltype = readRDS(file = "~/Dropbox/pseudoT.example.cell.types.rds")
data = gficf(M = M.raw,cell_proportion_max = 1,cell_proportion_min = .05,storeRaw=T,normalize = T)
data = runPCA(data = data,dim = 50,var.scale = T,centre = T,use.odgenes = T,n.odgenes = 3000,plot.odgenes = T)
data = runReduction(data = data,reduction = "umap",nt = 6,n_neighbors = 15,ret_model_pred = T,metric="euclidean")
data$embedded$cell.id = rownames(data$embedded)
data$embedded$sample = "A"
data$embedded$celltype = celltype
p1 = gficf::plotCells(data = data,colorBy = "sample")
print(p1) + xlab("") + ylab("")

data = gficf::clustcells(data = data,from.embedded = F,k = 50,dist.method = "euclidean",nt = 6,community.algo = "louvian 2",store.graph = T,verbose = T,resolution = 1,n.start = 100,n.iter = 250)

gficf::plotCells(data = data,colorBy = "cluster")

gficf::plotCells(data = data,colorBy = "celltype")

#data = gficf::findClusterMarkers(data = data,nt = 6,hvg = T,verbose = T)
#data$de.genes = gficf::ensToSymbol(df = data$de.genes,col = "ens",organism = "human")

data = gficf::runPseudoTime(data = data,hgv = T,parallel = F,verbose = T,start.cl = 2)
plotGeneCount(curve = data$pseudoT$crv, clusters = data$embedded$celltype,models = data$pseudoT$sce)

head(data$pseudoT)
data = gficf:::add.gp.score(data = data,curve = 2)
